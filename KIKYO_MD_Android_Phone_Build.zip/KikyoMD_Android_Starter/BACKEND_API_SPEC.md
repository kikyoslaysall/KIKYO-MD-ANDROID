# KIKYO MD mobile API contract (required before live features can work)

The Android app must connect to the existing KIKYO game engine through a public HTTPS API. The app must never connect directly to the Pterodactyl panel or contain bot session files, panel passwords, or private tokens.

## Shared account identity

WhatsApp, Telegram and Android must resolve a player to the same canonical trainer record on the server. The three approved master-owner phone numbers should be mapped server-side to the one canonical master profile chosen by the owner. Do not create three separate Pokémon inventories. Phone numbers and owner privileges must be verified on the server, not trusted from the app.

## Suggested endpoints

All endpoints use JSON and `/api/v1`.

- `POST /auth/request-otp` — request a one-time sign-in code for a verified phone number.
- `POST /auth/verify-otp` — verify the code and return a short-lived access token plus refresh token.
- `POST /auth/refresh` — rotate/refresh the access token.
- `GET /me` — trainer profile, canonical trainer ID, level, badges, currency and guild.
- `GET /pokemon/collection` — party, PC and Pokédex summary.
- `POST /pokemon/party` — update party order/selection.
- `GET /inventory` — items and Poké Balls.
- `GET /world` — active region, weather, day/night and world events.
- `GET /regions` — region unlocks and available exploration content.
- `GET /battles` — available PvP/PvE/raid activities.
- `POST /battles/{battleId}/actions` — submit a validated battle action.
- `POST /battles/{battleId}/forfeit` — request a forfeit; server validates battle state and opponent rules.
- `GET /pve/progress` — leader unlocks, wins and rewards.
- `GET /raids` — active raids and participation status.
- `GET /league` — season, ranking and rewards.
- `GET /guild` — guild membership and details.

## Response and security rules

- Require HTTPS and bearer-token authentication for private endpoints.
- Validate every action, reward, catch, trade and battle result on the server. Never trust client-calculated results.
- Use stable canonical trainer IDs so all connected platforms see the same progress.
- Return consistent errors: `{ "error": { "code": "...", "message": "..." } }`.
- Add rate limits to OTP and gameplay actions; never expose whether an arbitrary phone number belongs to an account.
- Keep owner/master authorization exclusively server-side.
- Use pagination for large collections and include a server timestamp/version for sync.

## Current state

This contract is a handoff specification, not a claim that these endpoints already exist. The starter app currently has a preview UI only. Live login, data, battles and cross-platform sync cannot be enabled until the KIKYO backend implements and publishes these endpoints and its HTTPS base URL.
