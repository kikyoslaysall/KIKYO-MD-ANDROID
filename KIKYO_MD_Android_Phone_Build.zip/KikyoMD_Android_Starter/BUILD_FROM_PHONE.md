# Build the APK using only an Android phone

This project now includes a GitHub Actions cloud build workflow. GitHub's servers compile the APK; you do not need a PC or Android Studio.

## One-time setup
1. Sign in to GitHub in your phone browser and create a **new private repository** named `KikyoMD-Android`.
2. Extract this ZIP on your phone using your file manager or an archive app.
3. In the repository, use **Add file → Upload files** and upload the *contents* of the `KikyoMD_Android_Starter` folder. Keep the `.github/workflows/build-apk.yml` path intact. If the mobile page hides Upload files, enable **Desktop site** in the browser menu.
4. Commit the uploaded files to the repository's `main` branch.
5. Open the repository's **Actions** tab, select **Build KIKYO MD APK**, choose **Run workflow**, and run it.
6. Wait for the run to finish successfully. Open that run, scroll to **Artifacts**, and download `KIKYO-MD-debug-APK`.
7. Extract the downloaded artifact ZIP. The installable file inside is `app-debug.apk`.

## Important
- The resulting debug APK is for testing and installation; it is not a signed Play Store release.
- The app is currently a UI preview. Live game login, Pokémon data, battles and syncing require the KIKYO backend API described in `BACKEND_API_SPEC.md`.
- Do not upload bot session files, passwords, OTPs, API secrets or Pterodactyl credentials to the repository.
