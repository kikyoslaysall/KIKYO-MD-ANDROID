package com.kikyo.md

/** Set this to the public HTTPS API base URL when the KIKYO backend is ready. */
object ApiConfig {
    const val BASE_URL = ""
    const val API_VERSION = "/api/v1"
    const val IS_CONFIGURED = false
}
